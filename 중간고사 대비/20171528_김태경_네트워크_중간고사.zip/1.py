str = 'Hello, IoT'

print(str * 3)
print(str[:4])
print(str[-4:])
print(str.lower())
print(str.find('IoT'))